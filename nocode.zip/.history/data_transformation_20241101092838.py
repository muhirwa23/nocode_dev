# data_transformation.py

from sklearn.preprocessing import StandardScaler, LabelEncoder

def handle_missing_values(df, method='drop', value=None):
    if method == 'drop':
        df = df.dropna()
    elif method == 'fill':
        if value is not None:
            df = df.fillna(value)
        else:
            raise ValueError("Value required for filling.")
    elif method == 'interpolate':
        df = df.interpolate()
    return df

def scale_data(df, columns):
    scaler = StandardScaler()
    df[columns] = scaler.fit_transform(df[columns])
    return df

def encode_categorical(df, columns):
    for col in columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
    return df
